import { node, empty, reverseList } from "../include/lists.js";
export function insertOrdered(lst, el) {
    // return reverseList(lst.reduce((acc, e) => {
    //   if (el < e)
    //     return node(e, node(el, acc));
    //   return node(e, acc);
    // }, empty()));
    if (lst.isEmpty() || el < lst.head())
        return node(el, lst);
    return node(lst.head(), insertOrdered(lst.tail(), el));
}
export function everyNRev(lst, n) {
    if (!Number.isInteger(n) || n < 1)
        return empty();
    let count = 0;
    return lst.reduce((acc, e) => {
        count++;
        if (count % n == 0)
            return node(e, acc);
        return acc;
    }, empty());
}
export function everyNCond(lst, n, cond) {
    if (!Number.isInteger(n) || n < 1)
        return empty();
    let count = 0;
    return lst.filter(e => {
        if (!cond(e))
            return false;
        count++;
        return count % n == 0;
    });
    // return reverseList(everyNRev(lst, n)).filter(e => cond(e));
}
export function keepTrendMiddles(lst, allSatisfy) {
    // let prev = lst.head();
    // let curr = lst.tail().head();
    // let next = lst.tail().tail().head();
    // let index = 0;
    // function poppedList(inputList: List<number>): List<number> {
    //   return node(inputList.tail().head(), inputList.tail().tail());
    // }
    // return lst.filter(e => {
    //   if (index === 0) {
    //     prev = e;
    //     return;
    //   }
    //   curr = e;
    // })
    // let newList: List<number> = empty();
    // const _l: List<number> = lst.reduce((acc, e) => {
    //   acc = node(e, acc);
    //   if (!acc.tail().isEmpty() && !acc.tail().tail().isEmpty()) {
    //     const bool = allSatisfy(acc.tail().tail().head(), acc.tail().head(), acc.head());
    //     acc = node(acc.head(), node(acc.tail().head(), empty()));
    //     if (bool)
    //       newList = node(acc.tail().head(), newList);
    //       return acc;
    //   }
    //   return acc;
    // }, empty());
    function trendMiddlesHelper(prev, rest) {
        if (rest.isEmpty() || rest.tail().isEmpty())
            return empty();
        const curr = rest.head();
        const next = rest.tail().head();
        return allSatisfy(prev, curr, next)
            ? node(curr, trendMiddlesHelper(curr, rest.tail()))
            : trendMiddlesHelper(curr, rest.tail());
    }
    return lst.isEmpty() ? lst : trendMiddlesHelper(lst.head(), lst.tail());
}
export function keepLocalMaxima(lst) {
    return keepTrendMiddles(lst, (prev, curr, next) => prev < curr && curr > next);
}
export function keepLocalMinima(lst) {
    return keepTrendMiddles(lst, (prev, curr, next) => prev > curr && curr < next);
}
export function keepLocalMinimaAndMaxima(lst) {
    return keepTrendMiddles(lst, (prev, curr, next) => (prev < curr && curr > next) || (prev > curr && curr < next));
}
function productHelper(lst, product, sign) {
    // if (lst.isEmpty() && acc.isEmpty()) return empty();
    // if (lst.isEmpty() || lst.head()*sign < 0) {
    //   const sum = acc.reduce((acc, e) => acc*e, 1);
    //   return node(sum, productHelper(lst.isEmpty() ? empty() : lst.tail(), empty(), sign));
    // }
    // acc = node(lst.head(), acc);
    // return productHelper(lst.tail(), acc, sign);
    // lst.reduce((acc, e) => {
    //   if(e > 0) {
    //     return node(e, acc);
    //   } else {
    //     acc.reduce((ac, y) => ac*y, 1)
    //   }
    //   return acc;
    // }, empty())
    if (lst.isEmpty())
        return empty();
    if (lst.head() >= 0 === sign >= 0) {
        product *= lst.head();
        return node(product, productHelper(lst.tail(), product, sign));
    }
    return productHelper(lst.tail(), 1, sign);
}
export function nonNegativeProducts(lst) {
    return productHelper(lst, 1, 1);
}
export function negativeProducts(lst) {
    return productHelper(lst, 1, -1);
}
export function deleteFirst(lst, el) {
    let flag = false;
    return reverseList(lst.reduce((acc, e) => {
        return flag ? node(e, acc) : el === e ? ((flag = true), acc) : node(e, acc);
    }, empty()));
}
export function deleteLast(lst, el) {
    return reverseList(deleteFirst(reverseList(lst), el));
}
export function squashList(lst) {
    return lst.map(e => {
        if (typeof e === "number")
            return e;
        return e.reduce((acc, e) => acc + e, 0);
    });
}
//# sourceMappingURL=lists.js.map