import { match } from "ts-pattern";
export const PARENT_STATE_KEY = Symbol("[[PARENT]]");
//helper functions
function checkAllStates(state, name) {
    if (!state)
        return undefined;
    return name in state ? state : checkAllStates(state[PARENT_STATE_KEY], name);
}
function runBlockStatements(state, stmts) {
    const blockState = { [PARENT_STATE_KEY]: state };
    stmts.forEach(s => interpStatement(blockState, s));
}
function evalBinaryOp(state, left, right, op) {
    const a = interpExpression(state, left);
    const b = interpExpression(state, right);
    if (typeof a === "number" && typeof b === "number")
        return op(a, b);
    throw new Error("Uncaught SyntaxError: Arithmetic may only happen between numbers");
}
function evalCompareOp(state, left, right, comparator) {
    const a = interpExpression(state, left);
    const b = interpExpression(state, right);
    if (typeof a === "number" && typeof b === "number")
        return comparator(a, b);
    throw new Error("Uncaught SyntaxError: Comparison may only happen between numbers");
}
function evalBooleanOp(state, op, left, right) {
    const a = interpExpression(state, left);
    if (typeof a !== "boolean") {
        throw new Error("Uncaught SyntaxError: Logical operations may only happen between boolean");
    }
    if (op === "&&" && !a)
        return false;
    if (op === "||" && a)
        return true;
    const b = interpExpression(state, right);
    if (typeof b !== "boolean") {
        throw new Error("Uncaught SyntaxError: Logical operations may only happen between boolean");
    }
    return b;
}
export function interpExpression(state, exp) {
    // TODO
    return (match(exp)
        .with({ kind: "boolean" }, { kind: "number" }, exp => exp.value)
        .with({ kind: "variable" }, exp => {
        const ref = checkAllStates(state, exp.name);
        if (ref !== undefined)
            return ref[exp.name];
        else
            throw new Error(`Uncaught ReferenceError: ${exp.name} is not defined`);
    })
        .with({ kind: "operator" }, exp => {
        return match(exp.operator)
            .with("+", () => evalBinaryOp(state, exp.left, exp.right, (a, b) => a + b))
            .with("-", () => evalBinaryOp(state, exp.left, exp.right, (a, b) => a - b))
            .with("*", () => evalBinaryOp(state, exp.left, exp.right, (a, b) => a * b))
            .with("/", () => evalBinaryOp(state, exp.left, exp.right, (a, b) => {
            if (b === 0)
                throw new Error("Uncaught RuntimeError: Division by zero is forbidden");
            return a / b;
        }))
            .with(">", () => evalCompareOp(state, exp.left, exp.right, (a, b) => a > b))
            .with("<", () => evalCompareOp(state, exp.left, exp.right, (a, b) => a < b))
            .with("===", () => interpExpression(state, exp.left) === interpExpression(state, exp.right))
            .with("&&", "||", op => evalBooleanOp(state, op, exp.left, exp.right))
            .exhaustive();
    })
        // .with({ kind: "function" }, () => false)
        // .with({ kind: "call" }, () => false)
        // .exhaustive();
        .otherwise(() => {
        throw new Error("Not yet implemented.");
    }));
}
export function interpStatement(state, stmt) {
    // TODO
    match(stmt)
        .with({ kind: "let" }, stmt => {
        if (stmt.name in state)
            throw new Error(`Uncaught SyntaxError: Identifier '${stmt.name}' has already been declared`);
        state[stmt.name] = interpExpression(state, stmt.expression);
    })
        .with({ kind: "assignment" }, stmt => {
        const ref = checkAllStates(state, stmt.name);
        if (ref === undefined)
            throw new Error(`Uncaught ReferenceError: ${stmt.name} is not defined`);
        ref[stmt.name] = interpExpression(state, stmt.expression);
    })
        .with({ kind: "if" }, stmt => {
        const test = interpExpression(state, stmt.test);
        test ? runBlockStatements(state, stmt.truePart) : runBlockStatements(state, stmt.falsePart);
    })
        .with({ kind: "while" }, stmt => {
        while (interpExpression(state, stmt.test))
            runBlockStatements(state, stmt.body);
    })
        .with({ kind: "print" }, stmt => {
        console.log(interpExpression(state, stmt.expression));
    })
        // .with({ kind: "expression" }, stmt => interpExpression(state, stmt.expression))
        // .with({ kind: "return" }, stmt => stmt)
        // .exhaustive();
        .otherwise(() => {
        throw new Error("Not yet implemented.");
    });
}
export function interpProgram(program) {
    // TODO
    const globalState = {};
    program.forEach(stmt => interpStatement(globalState, stmt));
    return globalState;
}
//# sourceMappingURL=interpreter.js.map