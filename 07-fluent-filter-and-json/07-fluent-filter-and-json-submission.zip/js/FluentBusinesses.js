export class FluentBusinesses {
    data;
    constructor(data) {
        this.data = data;
    }
    getData() {
        return this.data;
    }
    fromCityInState(city, state) {
        const filteredData = this.data.filter(business => business.city === city && business.state === state);
        return new FluentBusinesses(filteredData);
    }
    hasStarsGeq(stars) {
        // TODO
        const filteredData = this.data.filter(business => business.stars !== undefined && business.stars >= stars);
        return new FluentBusinesses(filteredData);
    }
    inCategory(category) {
        // TODO
        const filteredData = this.data.filter(business => business.categories !== undefined && business.categories.includes(category));
        return new FluentBusinesses(filteredData);
    }
    hasHoursOnDays(days) {
        // TODO
        const filteredData = this.data.filter(business => business.hours !== undefined && days.every(day => business.hours !== undefined && day in business.hours));
        return new FluentBusinesses(filteredData);
    }
    hasAmbience(ambience) {
        // TODO
        const filteredData = this.data.filter(business => business.attributes?.Ambience !== undefined && business.attributes.Ambience[ambience]);
        return new FluentBusinesses(filteredData);
    }
    // private hasSameValueFor(bus1: Business, bus2: Business, key: keyof Business): boolean {
    //   return bus1[key] === bus2[key];
    // }
    higherByKey(bus1, bus2, key) {
        const val1 = bus1 ? bus1[key] : undefined;
        const val2 = bus2 ? bus2[key] : undefined;
        if (val1 === val2)
            return undefined;
        if (val1 === undefined)
            return val2 === undefined ? undefined : bus2;
        if (val2 === undefined)
            return bus1;
        return val1 > val2 ? bus1 : bus2;
    }
    higherStars(bus1, bus2) {
        return this.higherByKey(bus1, bus2, "stars");
    }
    higherReviews(bus1, bus2) {
        return this.higherByKey(bus1, bus2, "review_count");
    }
    // private higherStars(bus1: Business, bus2: Business): Business | undefined {
    //   if (this.hasSameValueFor(bus1, bus2, "stars")) return undefined;
    //   if (bus1.stars === undefined && bus2.stars !== undefined) return bus2;
    //   if (bus1.stars !== undefined && bus2.stars === undefined) return bus1;
    //   return bus1.stars !== undefined && bus2.stars !== undefined && bus1.stars > bus2.stars ? bus1 : bus2;
    // }
    // private higherReviews(bus1: Business, bus2: Business): Business | undefined {
    //   if (this.hasSameValueFor(bus1, bus2, "review_count")) return undefined;
    //   if (bus1.review_count === undefined && bus2.review_count !== undefined) return bus2;
    //   if (bus1.review_count !== undefined && bus2.review_count === undefined) return bus1;
    //   return bus1.review_count !== undefined && bus2.review_count !== undefined && bus1.review_count > bus2.review_count
    //     ? bus1
    //     : bus2;
    // }
    bestPlace() {
        // TODO
        const best = this.data.reduce((acc, business) => {
            if (business.stars === undefined)
                return acc;
            const x = this.higherStars(business, acc);
            const y = this.higherReviews(business, acc);
            return x ? x : y ? y : acc;
        }, undefined); // { business_id: "undefined" }
        return best;
        // return best.business_id === "undefined" ? undefined : best;
        // return Object.keys(best).length === 0 ? undefined : best;
    }
    mostReviews() {
        // TODO
        const most = this.data.reduce((acc, business) => {
            if (business.review_count === undefined)
                return acc;
            const x = this.higherReviews(business, acc);
            const y = this.higherStars(business, acc);
            return x ? x : y ? y : acc;
        }, undefined);
        return most;
        // return most.business_id === "undefined" ? undefined : most;
        // return Object.keys(most).length === 0 ? undefined : most;
    }
}
//# sourceMappingURL=FluentBusinesses.js.map